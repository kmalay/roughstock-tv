sub init()
    m.top.functionName = "runBeepLoop"
end sub

sub runBeepLoop()
    audioRes = CreateObject("roAudioResource", "pkg:/sounds/beep.wav")
    port = CreateObject("roMessagePort")
    m.top.observeFieldScoped("trigger", port)
    while true
        msg = wait(0, port)
        if msg <> invalid then audioRes.Trigger(75)
    end while
end sub
